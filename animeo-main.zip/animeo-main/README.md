---
title: Animeo
emoji: ⚡
colorFrom: green
colorTo: pink
sdk: docker
pinned: false
app_port: 3003
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
